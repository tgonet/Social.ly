package sg.MAD.socially.Notifications;

public class MyResponse {
    public int success;
}
